<?php
/**
 * The template used for displaying page content
 *
 * @package WordPress
 * @subpackage owntheme
 * @since owntheme 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>



<div class="inner-page-header">
<div class="container">
<div class="row">
	<?php
		// Post thumbnail.
		//lyb_post_thumbnail();
	?>	
	
<div class="col-sm-6">

	<div class="entry-header">
		<?php the_title( '<h2 class="entry-title">', '</h2>' ); ?>
	</div><!-- .entry-header -->
	</div>
<div class="col-sm-6">
<?php custom_breadcrumbs(); ?>
	</div>

</div>
</div>
</div>
    
<div class="container">


	<div class="entry-content">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'owntheme' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'owntheme' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );
		?>
	</div><!-- .entry-content -->

	<?php edit_post_link( __( 'Edit', 'owntheme' ), '<div class="entry-footer"><span class="edit-link">', '</span></div><!-- .entry-footer -->' ); ?>
</div>
</article><!-- #post-## -->

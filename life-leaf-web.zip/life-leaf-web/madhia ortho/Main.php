<?php
/*
Template Name: Home
*/
?>
<?php get_header(); ?>


<!-- home-banner -->
  <section class="home-banner">
    <img src="<?php echo get_template_directory_uri(); ?>/images/home-medicine.png" class="home-medicine" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/coffee-1.png" class="coffee" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/capsule-2.png" class="capsule" alt="">
    <div class="container">
      <div class="row">
        <div class="col-lg-7 col-md-7">

             <div class="banner_slider owl-carousel owl-theme ">
        <div class="item">

          <div class="banner-text">
            <h1><span>EXPLORE</span> OUR RANGE</h1>
            <h4>Is best Quality with Service</h4>
            <p>On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de
              distractions, concentrer sur mise en page elle-meme.</p>
              <div class="button-outer">
                <a href="#" class="btn1">Contact Us</a>
                <a href="#" class="btn2">Connect with Whatsapp</a>
                <a href="#" class="whatsapp_btn"><i class="fa-brands fa-whatsapp"></i></a>
              </div>
            </div>
                 </div>
                   <div class="item">

          <div class="banner-text">
            <h1><span>EXPLORE</span> OUR RANGE</h1>
            <h4>Is best Quality with Service</h4>
            <p>On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de
              distractions, concentrer sur mise en page elle-meme.</p>
              <div class="button-outer">
                <a href="#" class="btn1">Contact Us</a>
                <a href="#" class="btn2">Connect with Whatsapp</a>
                <a href="#" class="whatsapp_btn"><i class="fa-brands fa-whatsapp"></i></a>
              </div>
            </div>
                 </div>
                   <div class="item">

          <div class="banner-text">
            <h1><span>EXPLORE</span> OUR RANGE</h1>
            <h4>Is best Quality with Service</h4>
            <p>On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de
              distractions, concentrer sur mise en page elle-meme.</p>
              <div class="button-outer">
                <a href="#" class="btn1">Contact Us</a>
                <a href="#" class="btn2">Connect with Whatsapp</a>
                <a href="#" class="whatsapp_btn"><i class="fa-brands fa-whatsapp"></i></a>
              </div>
            </div>
                 </div>
          </div>
        </div>
        <div class="col-lg-5 col-md-5">
          <div class="banner_doctor">
            <img src="<?php echo get_template_directory_uri(); ?>/images/doctor.png" alt=""/>
            <div class="counter-item">
              <div class="counting" data-count="117542">117542+</div><span><i class="fa-regular fa-plus"></i></span>
              <br>
              <h6>HAPPY <span>CUSTOMERS</span></h6>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="hbg-circle">
      <div class="innner-circle"></div>
    </div>
  </section>
  <!-- our renges section -->
  <section class="our_ranges section_gap">
    <div class="container">
      <div class="heading text-center">
        <h5>Our Range</h5>
        <h2>Our <span>Priority</span></h2>
        <p>There's a visible quality difference in all our products</p>
      </div>
      <div class="product_slider owl-carousel owl-theme gap-top">
        <div class="item">
          <div class="product-item">
            <a href="" class="image-block"><img src="<?php echo get_template_directory_uri(); ?>/images/products/products-1.jpg" alt=""></a>
            <div class="product-details">
              <p><a href="#">Trauma Products</a></p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="product-item">
            <a href="" class="image-block"><img src="<?php echo get_template_directory_uri(); ?>/images/products/products-2.jpg" alt=""></a>
            <div class="product-details">
              <p><a href="#">Locking System</a></p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="product-item">
            <a href="" class="image-block"><img src="<?php echo get_template_directory_uri(); ?>/images/products/products-3.jpg" alt=""></a>
            <div class="product-details">
              <p><a href="#">Hip System</a></p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="product-item">
            <a href="" class="image-block"><img src="<?php echo get_template_directory_uri(); ?>/images/products/products-1.jpg" alt=""></a>
            <div class="product-details">
              <p><a href="#">Spine Systems</a></p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="product-item">
            <a href="" class="image-block"><img src="<?php echo get_template_directory_uri(); ?>/images/products/products-1.jpg" alt=""></a>
            <div class="product-details">
              <p><a href="#">Trauma Products</a></p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="product-item">
            <a href="" class="image-block"><img src="<?php echo get_template_directory_uri(); ?>/images/products/products-2.jpg" alt=""></a>
            <div class="product-details">
              <p><a href="#">Locking System</a></p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="product-item">
            <a href="" class="image-block"><img src="<?php echo get_template_directory_uri(); ?>/images/products/products-3.jpg" alt=""></a>
            <div class="product-details">
              <p><a href="#">Hip System</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Orthopedic Implants & Instruments -->
  <section class="orthopedicimplants_section section_gap">
    <img src="<?php echo get_template_directory_uri(); ?>/images/circle-gradient.png" class="cg-image" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/capsule-group.png" class="capsule" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/Ellipse1.png" class="half-circle" alt="">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-5 col-md-6">
          <div class="image-outer">
            <img src="<?php echo get_template_directory_uri(); ?>/images/instrumental-image.jpg" alt="">
            <a data-fancybox href="https://youtu.be/7mLCLx2-dQs" class="video_btn"><i
                class="fa-regular fa-circle-play"></i></a>
          </div>
        </div>
        <div class="col-lg-7 col-md-6">
          <div class="heading">
            <h5>Welcome to MADIHA ORTHO</h5>
            <h2><span>The World Best Quality Orthopedic</span> Implants <span>&</span> Instruments</h2>
            <p>We at Madiha Ortho strive hard to meet the expectations of our users by offering international standard
              quality product which is easy procurable and affordable without compromising with the most important word
              of medical devices Safety.</p>
            <div class="button-outer">
              <a href="#" class="btn1">Know More</a>
            </div>
          </div>
        </div>
      </div>
  </section>
  <!-- bg-1-section -->
  <section class="bg-1 section_gap content-white">
    <img src="<?php echo get_template_directory_uri(); ?>/images/capsule-3.png" class="capsule-1" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/capsule-2.png" class="capsule-2" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/capsule-1.png" class="capsule-3" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/shape-1.png" class="shape-1" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/shape-2.png" class="shape-2" alt="">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="heading">
            <h5>Our Service Offers</h5>
            <h2>What Madiha Ortho Means Around the World</h2>
            <p>At Madiha we work with passion to help others live fearlessly. Our emphasis is not on figures but on
              individual Stories.</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6">
          <div class="service-box">
            <h4>Excellent Service</h4>
            <p>Madiha Ortho is committed to provide best quality product in time at affordable rates with modern
              technological solution.</p>
            <span class="s-icon">
              <img src="<?php echo get_template_directory_uri(); ?>/images/service-icon-1.png" alt="">
            </span>
          </div>
          <div class="service-box">
            <h4>Latest Technology</h4>
            <p>Empowerment of individuals has taken the front stage and could achieve more by working together.</p>
            <span class="s-icon even">
              <img src="<?php echo get_template_directory_uri(); ?>/images/service-icon-2.png" alt="">
            </span>
          </div>
          <div class="service-box">
            <h4>Inhouse Total Operation</h4>
            <p>Equipment making is a highly developed craft and the craftspeople who make Madiha Ortho</p>
            <span class="s-icon">
              <img src="<?php echo get_template_directory_uri(); ?>/images/service-icon-3.png" alt="">
            </span>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 left-padding">
          <div class="service-box">
            <h4>Product Compatibility</h4>
            <p>To ensure patient safety, refer to the package insert or other accompanying product information.</p>
            <span class="s-icon even">
              <img src="<?php echo get_template_directory_uri(); ?>/images/service-icon-4.png" alt="">
            </span>
          </div>
          <div class="service-box">
            <h4>Zero Defect Products</h4>
            <p>Quality of the products is maintained by adopting QMS system as per ISO 13485:2016 system.</p>
            <span class="s-icon">
              <img src="<?php echo get_template_directory_uri(); ?>/images/service-icon-5.png" alt="">
            </span>
          </div>
          <div class="service-box">
            <h4>Quality and Reliability</h4>
            <p>To provide outstanding quality comparable to internationally recognized Surgical Implants that are
              reliable & safe during operation.</p>
            <span class="s-icon even">
              <img src="<?php echo get_template_directory_uri(); ?>/images/service-icon-6.png" alt="">
            </span>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- counter section -->
  <section class="counter_section section_gap">
    <img src="<?php echo get_template_directory_uri(); ?>/images/coffee-1.png" class="coffee-1" alt="">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6 col-6">
          <div class="counter-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/counter-img-1.png" alt="">
            <br>
            <div class="counting" data-count="675"></div><span><i class="fa-regular fa-plus"></i></span>
            <br>
            <h6>Our Dealers</h6>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-6">
          <div class="counter-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/counter-img-2.png" alt="">
            <br>
            <div class="counting" data-count="117542"></div><span><i class="fa-regular fa-plus"></i></span>
            <br>
            <h6>Happy Customers</h6>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-6">
          <div class="counter-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/counter-img-3.png" alt="">
            <br>
            <div class="counting" data-count="248"> </div>
            <br>
            <h6>Hospital/Doctors</h6>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-6">
          <div class="counter-item">
            <img src="<?php echo get_template_directory_uri(); ?>/images/counter-img-4.png" alt="">
            <br>
            <div class="counting" data-count="24"></div>
            <br>
            <h6>24X7 Help Desk</h6>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- contact us section -->
  <section class="contactus_section section_gap">
    <img src="<?php echo get_template_directory_uri(); ?>/images/circle-dot.png" class="circle-1" alt="">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="pr-box bg-green">
            <h4>Our Range Of Products</h4>
            <ul>
              <li>Bone Screw</li>
              <li>Bone Plate</li>
              <li>Locking Screw</li>
              <li>Locking Plate</li>
              <li>Nailing System</li>
              <li>Wire and Pins</li>
              <li>Hip System</li>
              <li>Spine System</li>
              <li>External</li>
              <li>Fixator</li>
              <li>Instruments</li>
            </ul>
          </div>
        </div>
        <div class="col-lg-8">
          <div class="contact-box">
            <img src="<?php echo get_template_directory_uri(); ?>/images/capsule-2.png" class="capsule-1" alt="">
            <div class="heading">
              <h5>Let's Get Connected with Us</h5>
              <h2><span>Drop Your</span> Message Now!</h2>
            </div>
            <div class="row">
              <div class="col-sm-5">
                <div class="contact-img">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/contact-img.png" class="contact-img" alt="">
                </div>
              </div>
              <div class="col-sm-7">
                <form action="" method="post" class="contact-form">
                  <input type="text" class="contact-input" placeholder="Enter name" />
                  <input type="text" class="contact-input" placeholder="Enter email" />
                  <input type="text" class="contact-input" placeholder="Enter phone" />
                  <textarea type="text" class="contact-input" placeholder="Message"></textarea>
                  <button type="submit" class="sub-btn">Submit Now</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- testimonial_section -->
  <section class="testimonial_section section_gap content-white">
    <img src="<?php echo get_template_directory_uri(); ?>/images/capsule-1.png" class="capsule-1" alt="">
    <img src="<?php echo get_template_directory_uri(); ?>/images/coffee-1.png" class="coffee-1" alt="">
    <div class="container">
      <div class="heading text-center">
        <h5>Our Feedback</h5>
        <h2>What Our Customer Says</h2>
      </div>
      <div class="testimonial_slider owl-carousel owl-theme">
        <div class="item">
          <div class="testimonial_item">
            <div class="customer_image">
              <img src="<?php echo get_template_directory_uri(); ?>/images/customer-1.png" class="customer-img" alt="">
            </div>
            <div class="customer_text">
              <h4 class="customer-name">MIke Hussain</h4>
              <ul class="list-inline rate">
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
              </ul>
              <p>On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de
                distractions, et empêche de se concentrer sur la mise en page elle-même. Du texte. Du texte.' est qu'il
                possède une distribution de lettres plus ou moins normale, et en tout cas comparable avec celle du
                français standard.</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="testimonial_item">
            <div class="customer_image">
              <img src="<?php echo get_template_directory_uri(); ?>/images/customer-1.png" class="customer-img" alt="">
            </div>
            <div class="customer_text">
              <h4 class="customer-name">MIke Hussain</h4>
              <ul class="list-inline rate">
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
              </ul>
              <p>On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de
                distractions, et empêche de se concentrer sur la mise en page elle-même. Du texte. Du texte.' est qu'il
                possède une distribution de lettres plus ou moins normale, et en tout cas comparable avec celle du
                français standard.</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="testimonial_item">
            <div class="customer_image">
              <img src="<?php echo get_template_directory_uri(); ?>/images/customer-1.png" class="customer-img" alt="">
            </div>
            <div class="customer_text">
              <h4 class="customer-name">MIke Hussain</h4>
              <ul class="list-inline rate">
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
                <li><i class="fa-regular fa-star"></i></li>
              </ul>
              <p>On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de
                distractions, et empêche de se concentrer sur la mise en page elle-même. Du texte. Du texte.' est qu'il
                possède une distribution de lettres plus ou moins normale, et en tout cas comparable avec celle du
                français standard.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


<?php get_footer(); ?>


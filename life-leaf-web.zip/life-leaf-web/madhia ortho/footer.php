<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage owntheme
 * @since owntheme 1.0
 Add on footer
 ----------------------
 <script>
$('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});
</script>
 */
?>
  <!--    ============ foot-top =================-->
    
    
    <!-- footer -->
  <div class="footer_div">
    <div class="container">
      <div class="row">
        <div class="col-lg-2 col-md-12">
          <div class="footer-logo">
            <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" class="" alt=""></a>
          </div>
        </div>
        <div class="col-lg-1"></div>
        <div class="col-lg-2 col-md-4">
          <div class="ft-content">
            <h4 class="ft-title">EXPLORE</h4>
            <ul class="list-unstyled ft-list">
              <li><a href="#">About</a></li>
              <li><a href="#">Product</a></li>
              <li><a href="#">Cetificate</a></li>
              <li><a href="#">Download</a></li>
              <li><a href="#">Contact</a></li>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="#">Terms & Conditions</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 col-md-4">
          <div class="ft-content">
            <h4 class="ft-title">ADDRESS</h4>
            <ul class="list-unstyled ft-contact">
              <li><i class="zmdi zmdi-pin"></i> <a href="#">No.212, Plot No.6,
                  Netaji Road, NH-8B, Veraval - Shapar - 360024
                  Dist. Rajkot, Gujarat, India</a></li>
              <li><i class="zmdi zmdi-phone-in-talk"></i> <a href="#">91 8777280771</a></li>
              <li><i class="zmdi zmdi-whatsapp"></i><a href="#">+91 9564121887</a></li>
            </ul>
            <h4 class="ft-title">Domestic Inquiry</h4>
            <ul class="list-unstyled ft-contact">
              <li><i class="zmdi zmdi-phone-in-talk"></i><a href="#">+91 9883254162</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4">
          <div class="ft-content nl-box">
            <h4 class="ft-title">NEWSLETTER</h4>
            <form action="" class="ft-nletter">
              <input type="text" placeholder="Please enter your Email Id">
              <button type="submit" class="nlsub-btn">Subscribe Now</button>
            </form>
            <ul class="list-inline ft-sclist">
              <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa-brands fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
              <li><a href="#"><i class="fa-brands fa-pinterest"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="copyright">
      <p>Copyright © 2022 <a href="#">Madiha Ortho</a>. All rights reserved.</p>
    </div>
  </div>
  <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/popper.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.cycle2/2.1.6/jquery.cycle2.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/custom.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/wow.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/webslidemenu.js"></script>
  <script>
    new WOW().init();
  </script>

  <script>
    $.fn.jQuerySimpleCounter = function (options) {
      var settings = $.extend({
        start: 0,
        end: 100,
        easing: 'swing',
        duration: 400,
        complete: ''
      }, options);

      var thisElement = $(this);

      $({ count: settings.start }).animate({ count: settings.end }, {
        duration: settings.duration,
        easing: settings.easing,
        step: function () {
          var mathCount = Math.ceil(this.count);
          thisElement.text(mathCount);
        },
        complete: settings.complete
      });
    };


    $('#number1').jQuerySimpleCounter({ end: 12, duration: 3000 });
    $('#number2').jQuerySimpleCounter({ end: 55, duration: 3000 });
    $('#number3').jQuerySimpleCounter({ end: 359, duration: 2000 });
    $('#number4').jQuerySimpleCounter({ end: 246, duration: 2500 });
  </script>

</body>

</html>

<?php wp_footer(); ?>

